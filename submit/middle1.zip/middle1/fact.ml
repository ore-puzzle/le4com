let rec fact = fun n ->
  if n < 1 then
    1
  else
    n * fact (n+ -1)
in
  fact 10;;
