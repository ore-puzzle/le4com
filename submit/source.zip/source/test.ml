let and = fun a -> fun b ->
    if a then
      if b then
        true
      else
        false
    else
      false in

and false true;;

