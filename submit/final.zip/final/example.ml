let e = 8 in
let mult8 = fun x ->
  loop c = (x, 0) in
    if 0 < c.1 then
      recur (c.1 + (-1), c.2 + e)
    else c.2 in
mult8 9;;

